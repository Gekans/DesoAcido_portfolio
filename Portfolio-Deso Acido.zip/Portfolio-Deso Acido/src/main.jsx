import React, { useState } from 'react'
import { createRoot } from 'react-dom/client'
import { ArrowDownRight, ArrowUpRight, BarChart3, Braces, Database, Layers3, Menu, Server, X } from 'lucide-react'
import './style.css'

const projects = [
  { id: '01', title: 'Service Desk', detail: 'Ticketing and support workflow', stack: 'React / Django', type: 'primary' },
  { id: '02', title: 'OpsBoard', detail: 'Operational analytics dashboard', stack: 'Dashboard / Data', type: 'cyan' },
  { id: '03', title: 'BlueLedger', detail: 'Records and reporting system', stack: 'System / Database', type: 'navy' },
]

function App() {
  const [open, setOpen] = useState(false)
  return <main>
    <header><a href="#home" className="brand"><i>J</i>DA<span>.</span></a><nav className={open ? 'open' : ''}><a href="#work" onClick={() => setOpen(false)}>Work</a><a href="#expertise" onClick={() => setOpen(false)}>Expertise</a><a href="#contact" onClick={() => setOpen(false)}>Contact</a></nav><a href="#contact" className="nav-cta">Start a project <ArrowUpRight size={15}/></a><button className="menu" onClick={() => setOpen(!open)}>{open ? <X/> : <Menu/>}</button></header>
    <section className="hero" id="home"><div className="hero-copy"><p className="label"><i/> IT Portfolio / 2025</p><h1>BUILDING<br/><em>better</em> digital<br/><span>systems.</span></h1><p className="intro">I&apos;m Justine Deso Acido, an IT developer focused on useful technology, thoughtful interfaces, and results that matter.</p><a href="#work" className="discover">Explore my work <ArrowDownRight/></a></div><div className="system-visual"><div className="visual-top"><span>JD.A / SYSTEMS</span><b>● LIVE</b></div><div className="visual-body"><div className="node node-a"><Server/><span>Services</span></div><div className="node node-b"><Database/><span>Data</span></div><div className="node node-c"><Braces/><span>Interface</span></div><svg viewBox="0 0 400 340" aria-hidden="true"><path d="M85 105 L200 170 L315 95 M200 170 L315 255"/><circle cx="85" cy="105" r="4"/><circle cx="200" cy="170" r="4"/><circle cx="315" cy="95" r="4"/><circle cx="315" cy="255" r="4"/></svg></div><div className="visual-bottom"><span>ALL SYSTEMS READY</span><span>100%</span></div></div></section>
    <section className="statement"><p className="label">01 / ABOUT</p><h2>Technology should feel<br/><i>clear, capable, and human.</i></h2><p>I develop reliable software experiences that make complex processes feel simple. My approach blends structured problem solving with a strong eye for clean UI.</p></section>
    <section className="work" id="work"><div className="section-top"><p className="label">02 / SELECTED WORK</p><span>2023 — 2025</span></div><div className="work-grid">{projects.map((project) => <article className={`project ${project.type}`} key={project.title}><div className="project-view"><div className="view-bar"><i/><i/><i/><span>project / {project.id}</span></div><div className="view-content"><b>{project.title}</b><div className="data-row"><i/><i/><i/></div><div className="chart"><span/><span/><span/><span/><span/></div></div></div><div className="project-text"><span>{project.id}</span><h3>{project.title}</h3><p>{project.detail}</p><small>{project.stack}</small><a href="#contact"><ArrowUpRight/></a></div></article>)}</div></section>
    <section className="expertise" id="expertise"><div><p className="label">03 / CAPABILITIES</p><h2>What I<br/><i>bring to the table.</i></h2></div><div className="capabilities"><article><Layers3/><span>01</span><h3>Web application<br/>development</h3><p>Responsive products built for real people and real work.</p></article><article><BarChart3/><span>02</span><h3>Data &amp; system<br/>workflows</h3><p>Organized processes, useful dashboards, and better visibility.</p></article><article><Braces/><span>03</span><h3>Interface &amp;<br/>experience design</h3><p>Clean, accessible interactions that make sense from the start.</p></article></div></section>
    <section className="contact" id="contact"><p className="label">04 / CONTACT</p><h2>Let&apos;s build<br/><i>what&apos;s next.</i></h2><a className="email" href="mailto:justine@desoacido.dev">justine@desoacido.dev <ArrowUpRight/></a><footer><span>© 2025 Justine Deso Acido</span><span>Based in the Philippines</span><a href="#home">Back to top ↑</a></footer></section>
  </main>
}
createRoot(document.getElementById('root')).render(<App />)
