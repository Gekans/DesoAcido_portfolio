@echo off
setlocal
title Justine Deso Acido Portfolio
cd /d "%~dp0"
if not exist "node_modules\" call npm.cmd install
start "Justine Deso Acido Portfolio" http://localhost:5176
call npm.cmd run dev -- --port 5176
endlocal
